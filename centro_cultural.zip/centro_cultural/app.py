from flask import Flask, render_template, request, redirect, url_for, flash, session
from datetime import datetime, date

app = Flask(__name__)
app.secret_key = 'clave_secreta_muy_segura_12345'

# Datos iniciales en memoria
USERS = [
    {'id': 1, 'nombre': 'Admin', 'documento': '1234567890', 'telefono': '3001234567', 
     'correo': 'admin@c.com', 'password': 'admin123', 'rol': 'administrador'},
    {'id': 2, 'nombre': 'Organizador', 'documento': '0987654321', 'telefono': '3109876543', 
     'correo': 'org@c.com', 'password': 'org12345', 'rol': 'organizador'},
    {'id': 3, 'nombre': 'Asistente', 'documento': '1122334455', 'telefono': '3201122334', 
     'correo': 'user@c.com', 'password': 'user1234', 'rol': 'asistente'}
]

LOCS = [
    {'id': 1, 'nombre': 'Auditorio', 'direccion': 'Calle 10', 'capacidad': 200, 'descripcion': 'Principal'},
    {'id': 2, 'nombre': 'Sala A', 'direccion': 'Calle 10 P2', 'capacidad': 50, 'descripcion': 'Conferencias'}
]

EVENTS = [
    {
        'id': 1, 
        'nombre': 'Festival Arte', 
        'descripcion': 'Exposición artistas con talleres.', 
        'fecha': '2025-12-15', 
        'horaInicio': '10:00', 
        'horaFin': '18:00', 
        'ubicacion': 'Auditorio', 
        'cupo': 100, 
        'creador': 2, 
        'asistentes': [3], 
        'confirmados': [], 
        'comentarios': [
            {'usuario': 'Asistente', 'texto': 'Genial!', 'fecha': '2025-11-01', 'reportado': False}
        ]
    }
]

# Funciones auxiliares
def get_user_by_email(correo):
    for user in USERS:
        if user['correo'] == correo:
            return user
    return None

def get_user_by_id(user_id):
    for user in USERS:
        if user['id'] == user_id:
            return user
    return None

def get_event_by_id(event_id):
    for event in EVENTS:
        if event['id'] == event_id:
            return event
    return None

def get_location_by_name(nombre):
    for location in LOCS:
        if location['nombre'] == nombre:
            return location
    return None

def can(permiso, user):
    if not user:
        return False
    if user['rol'] == 'administrador':
        return True
    if user['rol'] == 'organizador':
        return permiso in ['gest', 'gloc']
    return False

# Rutas principales
@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        correo = request.form.get('correo', '').strip()
        password = request.form.get('password', '').strip()
        
        user = get_user_by_email(correo)
        
        if user and user['password'] == password:
            session['user_id'] = user['id']
            session['user_rol'] = user['rol']
            session['user_nombre'] = user['nombre']
            flash('¡Bienvenido ' + user['nombre'] + '!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Error: Correo o contraseña incorrectos', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['POST'])
def register():
    try:
        nombre = request.form.get('nombre', '').strip()
        documento = request.form.get('documento', '').strip()
        telefono = request.form.get('telefono', '').strip()
        correo = request.form.get('correo', '').strip()
        password = request.form.get('password', '').strip()
        
        # Validaciones
        if not nombre:
            flash('El nombre es requerido', 'error')
            return redirect(url_for('login'))
        
        if len(documento) != 10 or not documento.isdigit():
            flash('El documento debe tener 10 dígitos', 'error')
            return redirect(url_for('login'))
        
        if len(telefono) != 10 or not telefono.isdigit():
            flash('El teléfono debe tener 10 dígitos', 'error')
            return redirect(url_for('login'))
        
        if not correo or '@' not in correo:
            flash('Correo electrónico inválido', 'error')
            return redirect(url_for('login'))
        
        if len(password) < 8:
            flash('La contraseña debe tener al menos 8 caracteres', 'error')
            return redirect(url_for('login'))
        
        if get_user_by_email(correo):
            flash('El correo ya está registrado', 'error')
            return redirect(url_for('login'))
        
        # Crear nuevo usuario
        new_id = max([u['id'] for u in USERS]) + 1 if USERS else 1
        new_user = {
            'id': new_id,
            'nombre': nombre,
            'documento': documento,
            'telefono': telefono,
            'correo': correo,
            'password': password,
            'rol': 'asistente'
        }
        
        USERS.append(new_user)
        flash('¡Cuenta creada exitosamente! Ya puedes iniciar sesión', 'success')
        return redirect(url_for('login'))
    
    except Exception as e:
        flash('Error al crear la cuenta: ' + str(e), 'error')
        return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = get_user_by_id(session['user_id'])
    if not user:
        session.clear()
        return redirect(url_for('login'))
    
    view = request.args.get('view', 'ev')
    today = date.today().isoformat()
    
    # Filtrar eventos según el usuario
    user_events = [e for e in EVENTS if session['user_id'] in e['asistentes']]
    manageable_events = [e for e in EVENTS if e['creador'] == session['user_id'] or session['user_rol'] == 'administrador']
    
    return render_template('dashboard.html',
                         user=user,
                         view=view,
                         events=EVENTS,
                         locations=LOCS,
                         users=USERS,
                         user_events=user_events,
                         manageable_events=manageable_events,
                         today=today,
                         can=can)

@app.route('/logout')
def logout():
    session.clear()
    flash('Sesión cerrada exitosamente', 'info')
    return redirect(url_for('login'))

# Gestión de eventos
@app.route('/event/register/<int:event_id>')
def register_event(event_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    event = get_event_by_id(event_id)
    if not event:
        flash('Evento no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    user_id = session['user_id']
    
    if user_id in event['asistentes']:
        flash('Ya estás inscrito en este evento', 'warning')
    elif len(event['asistentes']) >= event['cupo']:
        flash('Cupo lleno para este evento', 'error')
    else:
        event['asistentes'].append(user_id)
        flash('¡Inscripción exitosa!', 'success')
    
    return redirect(url_for('dashboard'))

@app.route('/event/confirm/<int:event_id>')
def confirm_event(event_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    event = get_event_by_id(event_id)
    if not event:
        flash('Evento no encontrado', 'error')
        return redirect(url_for('dashboard'))
    
    user_id = session['user_id']
    
    if user_id in event['asistentes'] and user_id not in event['confirmados']:
        event['confirmados'].append(user_id)
        flash('¡Confirmación exitosa!', 'success')
    elif user_id not in event['asistentes']:
        flash('No estás inscrito en este evento', 'error')
    else:
        flash('Ya habías confirmado tu asistencia', 'warning')
    
    return redirect(url_for('dashboard', view='mis'))

@app.route('/event/create', methods=['POST'])
def create_event():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = get_user_by_id(session['user_id'])
    if not can('gest', user):
        flash('No tienes permisos para crear eventos', 'error')
        return redirect(url_for('dashboard'))
    
    try:
        nombre = request.form.get('nombre', '').strip()
        descripcion = request.form.get('descripcion', '').strip()
        fecha = request.form.get('fecha', '').strip()
        hora_inicio = request.form.get('hora_inicio', '').strip()
        hora_fin = request.form.get('hora_fin', '').strip()
        ubicacion = request.form.get('ubicacion', '').strip()
        cupo = request.form.get('cupo', '0').strip()
        
        # Validaciones
        if not all([nombre, descripcion, fecha, hora_inicio, hora_fin, ubicacion, cupo]):
            flash('Completa todos los campos requeridos', 'error')
            return redirect(url_for('dashboard', view='gest'))
        
        if not get_location_by_name(ubicacion):
            flash('Ubicación no válida', 'error')
            return redirect(url_for('dashboard', view='gest'))
        
        try:
            cupo_int = int(cupo)
            if cupo_int <= 0:
                flash('El cupo debe ser mayor a 0', 'error')
                return redirect(url_for('dashboard', view='gest'))
        except ValueError:
            flash('Cupo debe ser un número válido', 'error')
            return redirect(url_for('dashboard', view='gest'))
        
        # Crear nuevo evento
        new_id = max([e['id'] for e in EVENTS]) + 1 if EVENTS else 1
        new_event = {
            'id': new_id,
            'nombre': nombre,
            'descripcion': descripcion,
            'fecha': fecha,
            'horaInicio': hora_inicio,
            'horaFin': hora_fin,
            'ubicacion': ubicacion,
            'cupo': cupo_int,
            'creador': session['user_id'],
            'asistentes': [],
            'confirmados': [],
            'comentarios': []
        }
        
        EVENTS.append(new_event)
        flash('Evento creado exitosamente', 'success')
        return redirect(url_for('dashboard', view='gest'))
    
    except Exception as e:
        flash('Error al crear el evento: ' + str(e), 'error')
        return redirect(url_for('dashboard', view='gest'))

@app.route('/event/delete/<int:event_id>')
def delete_event(event_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = get_user_by_id(session['user_id'])
    event = get_event_by_id(event_id)
    
    if not event:
        flash('Evento no encontrado', 'error')
        return redirect(url_for('dashboard', view='gest'))
    
    if event['creador'] != session['user_id'] and user['rol'] != 'administrador':
        flash('No tienes permisos para eliminar este evento', 'error')
        return redirect(url_for('dashboard', view='gest'))
    
    EVENTS.remove(event)
    flash('Evento eliminado exitosamente', 'success')
    return redirect(url_for('dashboard', view='gest'))

# Gestión de ubicaciones
@app.route('/location/create', methods=['POST'])
def create_location():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = get_user_by_id(session['user_id'])
    if not can('gloc', user):
        flash('No tienes permisos para gestionar ubicaciones', 'error')
        return redirect(url_for('dashboard'))
    
    try:
        nombre = request.form.get('nombre', '').strip()
        direccion = request.form.get('direccion', '').strip()
        capacidad = request.form.get('capacidad', '0').strip()
        descripcion = request.form.get('descripcion', '').strip()
        
        if not all([nombre, direccion, capacidad]):
            flash('Completa todos los campos obligatorios', 'error')
            return redirect(url_for('dashboard', view='gloc'))
        
        if any(l['nombre'] == nombre for l in LOCS):
            flash('Ya existe una ubicación con ese nombre', 'error')
            return redirect(url_for('dashboard', view='gloc'))
        
        try:
            capacidad_int = int(capacidad)
            if capacidad_int <= 0:
                flash('La capacidad debe ser mayor a 0', 'error')
                return redirect(url_for('dashboard', view='gloc'))
        except ValueError:
            flash('Capacidad debe ser un número válido', 'error')
            return redirect(url_for('dashboard', view='gloc'))
        
        new_id = max([l['id'] for l in LOCS]) + 1 if LOCS else 1
        new_location = {
            'id': new_id,
            'nombre': nombre,
            'direccion': direccion,
            'capacidad': capacidad_int,
            'descripcion': descripcion or ''
        }
        
        LOCS.append(new_location)
        flash('Ubicación creada exitosamente', 'success')
        return redirect(url_for('dashboard', view='gloc'))
    
    except Exception as e:
        flash('Error al crear la ubicación: ' + str(e), 'error')
        return redirect(url_for('dashboard', view='gloc'))

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)